import React from "react";

function About() {
  return (
    <>
      <h2>About</h2>
      <p>some text</p>
    </>
  );
}

export default About;
