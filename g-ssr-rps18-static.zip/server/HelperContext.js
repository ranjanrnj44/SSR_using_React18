// import React, { useContext } from "react";
// //App Component
// import App from "./App";

// //PropsContext
// import { DataProvider } from "../server/server";
// //component
// let RootComponent = () => {
//   //contextData
//   const { colorData, name, fetchData } = useContext(DataProvider);
//   return (
//     <>
//       <App colorData={colorData} name={name} fetchedData={fetchData} />
//     </>
//   );
// };

// export default RootComponent;
